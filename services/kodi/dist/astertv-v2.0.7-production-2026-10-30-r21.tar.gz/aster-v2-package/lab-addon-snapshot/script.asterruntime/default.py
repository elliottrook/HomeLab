"""Strict dispatcher for Aster's installed page runtime."""
import runpy
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
COMPONENTS={"aster-camera2","aster-digest-player8","aster-digest-reader6","aster-global-search-ui22",
 "aster-home-status1","aster-network-preview6","aster-series-preview24","aster-video-scrub5"}
ENTRIES={"default":"default.py","movie":"movie.py","view":"view.py"}
if len(sys.argv)>=3 and sys.argv[1] in COMPONENTS and sys.argv[2] in ENTRIES:
 path=ROOT/sys.argv[1]/ENTRIES[sys.argv[2]]
 if path.is_file() and not path.is_symlink():
  sys.argv=[str(path)]+sys.argv[3:]
  runpy.run_path(str(path),run_name="__main__")
