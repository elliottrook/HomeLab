#!/usr/bin/env python3
"""Checkpointed AsterTV-lab-only Seerr recommendation deep-link repair."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time

STAGE = Path('/storage/.aster-staging/astertv-v206-recommendation-seed')
CHECKPOINT = Path('/storage/.aster-checkpoints/astertv-v206-recommendation-seed-20261030-r2')
ROOT = Path('/storage/.kodi/addons')
LOCK = Path('/storage/.aster-checkpoints/aster-global-search-20261024/native-driver.lock')
FILES = {
    'script.asteracquisition/default.py': '0b9d5fcfb55aac34dd5527d5fd9cb37d695da29138e859eb072cdf682bf78714',
    'script.asterseerr/default.py': '0fb1695faee3f1a21dbdbd8d65b4a98a7ccb5d14b8d0b6d36e5983ed6bb1b36c',
    'screensaver.asterhome.v2lab/resources/skins/Default/1080i/AsterIdle.xml':
        '58d7d190eb49e040c91454a110eb44f70ffb61700e46fa23ef9ffc7d78c8dc79',
}


def require(ok, code):
    if not ok:
        raise ValueError(code)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rpc():
    packet = b'{"jsonrpc":"2.0","id":1,"method":"Player.GetActivePlayers"}\n'
    with socket.create_connection(('127.0.0.1', 9090), timeout=3) as client:
        client.sendall(packet)
        result = json.loads(client.recv(8192))
    require('error' not in result and result.get('result') == [], 'recommendation-player-active')


def wait_rpc(timeout=30):
    end = time.monotonic() + timeout
    last = None
    while time.monotonic() < end:
        try:
            rpc()
            return
        except (OSError, ValueError, json.JSONDecodeError) as error:
            last = error
            time.sleep(.25)
    raise RuntimeError('recommendation-rpc-not-ready') from last


def run(*args):
    return subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, text=True, timeout=45, check=True)


def atomic(dst, src):
    fd, temp = tempfile.mkstemp(prefix='.aster-seerr-seed-', dir=str(dst.parent))
    try:
        with os.fdopen(fd, 'wb') as output, src.open('rb') as input_file:
            shutil.copyfileobj(input_file, output); output.flush(); os.fsync(output.fileno())
        os.chmod(temp, 0o644); os.replace(temp, dst)
    finally:
        if os.path.exists(temp): os.unlink(temp)


def apply(pin):
    require(os.uname().nodename == 'AsterTV', 'recommendation-lab-only')
    manifest_path = STAGE / 'manifest.json'
    require(digest(manifest_path) == pin, 'recommendation-manifest-pin')
    manifest = json.loads(manifest_path.read_text())
    require(manifest.get('files') and {row['path'] for row in manifest['files']} == set(FILES),
            'recommendation-target-set')
    require(not CHECKPOINT.exists(), 'recommendation-checkpoint-exists')
    for row in manifest['files']:
        payload = STAGE / 'payload' / row['path']
        require(payload.is_file() and digest(payload) == row['sha256'], 'recommendation-payload')
        require(digest(ROOT / row['path']) == FILES[row['path']], 'recommendation-predecessor')
    rpc()
    fd = os.open(str(LOCK), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    stopped = False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        CHECKPOINT.mkdir(mode=0o700)
        for row in manifest['files']:
            src = ROOT / row['path']; backup = CHECKPOINT / 'original' / row['path']
            backup.parent.mkdir(mode=0o700, parents=True, exist_ok=True); shutil.copy2(src, backup)
        (CHECKPOINT / 'manifest.json').write_bytes(manifest_path.read_bytes())
        (CHECKPOINT / 'state.json').write_text('{"state":"prepared"}\n')
        rpc(); run('/usr/bin/systemctl', 'stop', 'kodi'); stopped = True
        for row in manifest['files']:
            atomic(ROOT / row['path'], STAGE / 'payload' / row['path'])
            require(digest(ROOT / row['path']) == row['sha256'], 'recommendation-installed-hash')
        run('/usr/bin/systemctl', 'start', 'kodi'); stopped = False
        end = time.monotonic() + 30
        while time.monotonic() < end:
            if run('/usr/bin/systemctl', 'is-active', 'kodi').stdout.strip() == 'active': break
            time.sleep(.25)
        require(run('/usr/bin/systemctl', 'is-active', 'kodi').stdout.strip() == 'active',
                'recommendation-kodi-inactive')
        wait_rpc()
        result = {'state':'installed','passed':True,'production_changed':False,
                  'files':len(manifest['files']),'checkpoint':str(CHECKPOINT),
                  'kodi_restarted':True,'player_idle':True,'manifest_sha256':pin}
        (CHECKPOINT / 'state.json').write_text(json.dumps(result, sort_keys=True)+'\n')
        return result
    except Exception:
        if CHECKPOINT.exists():
            if not stopped: run('/usr/bin/systemctl', 'stop', 'kodi'); stopped = True
            for row in manifest['files']:
                dest = ROOT / row['path']; current = digest(dest)
                require(current in (row['sha256'], FILES[row['path']]), 'recommendation-rollback-drift')
                if current == row['sha256']:
                    atomic(dest, CHECKPOINT / 'original' / row['path'])
            run('/usr/bin/systemctl', 'start', 'kodi'); stopped = False
            (CHECKPOINT / 'state.json').write_text('{"state":"rolled_back"}\n')
        raise
    finally:
        os.close(fd)


if __name__ == '__main__':
    import sys
    require(len(sys.argv) == 2, 'recommendation-arguments')
    print(json.dumps(apply(sys.argv[1]), sort_keys=True))
