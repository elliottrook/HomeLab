#!/usr/bin/env python3
"""Checkpointed AsterTV lab Settings logo correction."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time

TARGET = Path('/storage/.kodi/addons/skin.asterhome/1080i/Settings.xml')
CHECKPOINT = Path('/storage/.aster-checkpoints/astertv-v206-settings-icon-20261030-r3')
LOCK = Path('/storage/.aster-checkpoints/aster-global-search-20261024/native-driver.lock')
BEFORE = '9c9f711940ae1acd5d8873b834ce7441d6a7d3efa820472edd391ea3c9ef362b'
AFTER = '1c2c50973d919f5ccff3c11247e3ff86c71f496f06135c6aa768e7565f770a16'


def require(ok, code):
    if not ok:
        raise ValueError(code)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rpc():
    packet = b'{"jsonrpc":"2.0","id":1,"method":"Player.GetActivePlayers"}\n'
    with socket.create_connection(('127.0.0.1', 9090), timeout=3) as client:
        client.sendall(packet)
        result = json.loads(client.recv(8192))
    require('error' not in result and result.get('result') == [], 'settings-icon-player-active')


def run(*args):
    return subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, text=True, timeout=45, check=True)


def atomic(dst, src):
    fd, temp = tempfile.mkstemp(prefix='.aster-settings-icon-', dir=str(dst.parent))
    try:
        with os.fdopen(fd, 'wb') as output, Path(src).open('rb') as source:
            shutil.copyfileobj(source, output); output.flush(); os.fsync(output.fileno())
        os.chmod(temp, 0o644); os.replace(temp, dst)
    finally:
        if os.path.exists(temp): os.unlink(temp)


def apply(payload):
    require(os.uname().nodename == 'AsterTV', 'settings-icon-lab-only')
    payload = Path(payload)
    require(payload.is_file() and digest(payload) == AFTER, 'settings-icon-payload')
    require(digest(TARGET) == BEFORE, 'settings-icon-predecessor')
    require(not CHECKPOINT.exists(), 'settings-icon-checkpoint-exists')
    rpc()
    fd = os.open(str(LOCK), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    stopped = False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        CHECKPOINT.mkdir(mode=0o700)
        original = CHECKPOINT / 'Settings.xml'
        shutil.copy2(TARGET, original)
        (CHECKPOINT / 'state.json').write_text(json.dumps({
            'state': 'prepared', 'before_sha256': BEFORE, 'after_sha256': AFTER,
            'target': str(TARGET), 'lab_only': True,
        }, sort_keys=True) + '\n')
        rpc(); run('/usr/bin/systemctl', 'stop', 'kodi'); stopped = True
        atomic(TARGET, payload)
        require(digest(TARGET) == AFTER, 'settings-icon-installed-hash')
        run('/usr/bin/systemctl', 'start', 'kodi'); stopped = False
        end = time.monotonic() + 30
        while time.monotonic() < end:
            if run('/usr/bin/systemctl', 'is-active', 'kodi').stdout.strip() == 'active': break
            time.sleep(.25)
        require(run('/usr/bin/systemctl', 'is-active', 'kodi').stdout.strip() == 'active',
                'settings-icon-kodi-inactive')
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            try: rpc(); break
            except (OSError, ValueError, json.JSONDecodeError): time.sleep(.25)
        else: raise RuntimeError('settings-icon-rpc-not-ready')
        result = {'state': 'installed', 'passed': True, 'production_changed': False,
                  'before_sha256': BEFORE, 'after_sha256': AFTER,
                  'checkpoint': str(CHECKPOINT), 'player_idle': True, 'kodi_restarted': True}
        (CHECKPOINT / 'state.json').write_text(json.dumps(result, sort_keys=True) + '\n')
        return result
    except Exception:
        if CHECKPOINT.exists():
            if not stopped: run('/usr/bin/systemctl', 'stop', 'kodi'); stopped = True
            if digest(TARGET) == AFTER: atomic(TARGET, CHECKPOINT / 'Settings.xml')
            require(digest(TARGET) == BEFORE, 'settings-icon-rollback-drift')
            run('/usr/bin/systemctl', 'start', 'kodi'); stopped = False
            (CHECKPOINT / 'state.json').write_text('{"state":"rolled_back"}\n')
        raise
    finally:
        os.close(fd)


if __name__ == '__main__':
    import sys
    require(len(sys.argv) == 2, 'settings-icon-arguments')
    print(json.dumps(apply(sys.argv[1]), sort_keys=True))
