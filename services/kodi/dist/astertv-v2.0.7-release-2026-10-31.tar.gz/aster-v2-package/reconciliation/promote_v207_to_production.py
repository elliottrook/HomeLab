#!/usr/bin/env python3
"""Install the final AsterTV v2.0.7 release on Family or Bedroom."""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
import shutil
import socket
import subprocess
import time

PACKAGE = Path(__file__).resolve().parents[1]
SNAPSHOT = PACKAGE / "lab-addon-snapshot"
SNAPSHOT_MANIFEST = PACKAGE / "lab-addon-snapshot-manifest.json"
RECONCILIATION = PACKAGE / "reconciliation"
KEYMAP_SOURCE = RECONCILIATION / "payload/userdata/keymaps/g20s-pro-plus.xml"
SPLASH_SOURCE = PACKAGE / "profile-overlay/media/Splash.png"
ADDONS = Path("/storage/.kodi/addons")
KEYMAP = Path("/storage/.kodi/userdata/keymaps/g20s-pro-plus.xml")
SPLASH = Path("/storage/.kodi/media/Splash.png")
CHECKPOINT = None
RELEASE = "astertv-v2.0.7-release-2026-10-31"
SPLASH_SHA = "912228f3866b33749905eb8154b470d3170fe4747f92799811470bb49b986cce"
CLOCK_SETTING = "locale.use24hourclock"
AUDIO_SETTINGS = (
    "audiooutput.audiodevice",
    "audiooutput.passthroughdevice",
    "audiooutput.passthrough",
    "audiooutput.channels",
    "audiooutput.config",
    "audiooutput.ac3passthrough",
    "audiooutput.eac3passthrough",
    "audiooutput.truehdpassthrough",
    "audiooutput.dtspassthrough",
    "audiooutput.dtshdpassthrough",
    "videoplayer.usedisplayasclock",
)
HDMI_ROUTE = "ALSA:hdmi:CARD=PCH,DEV=0|HDA Intel PCH"
RELEASE_AUDIO = {
    "audiooutput.audiodevice": HDMI_ROUTE,
    "audiooutput.passthroughdevice": HDMI_ROUTE,
    "audiooutput.passthrough": True,
    "audiooutput.channels": 1,
    "audiooutput.config": 2,
    "audiooutput.ac3passthrough": True,
    "audiooutput.eac3passthrough": True,
    "audiooutput.truehdpassthrough": True,
    "audiooutput.dtspassthrough": False,
    "audiooutput.dtshdpassthrough": False,
    "videoplayer.usedisplayasclock": False,
}
GUISETTINGS = Path("/storage/.kodi/userdata/guisettings.xml")
PULSE = "pulseaudio.service"
RUNTIME_ADDONS = (
    "screensaver.asterhome.v2lab",
    "script.asteracquisition",
    "script.astermusic.v2lab",
    "script.asterruntime",
    "script.asterseerr",
    "script.astervoice.v2lab",
    "service.aster.playerui",
    "service.aster.startup",
)
LAB_ONLY_ADDONS = ("script.asterbootstrap",)
TARGETS = {
    "AsterTVProd": ("family", True),
    "AsterTV-Family": ("family", True),
    "AsterTV": ("bedroom", False),
    "AsterTV-Bedroom": ("bedroom", False),
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def kodi_rpc(method: str, params: dict | None = None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params
    with socket.create_connection(("127.0.0.1", 9090), timeout=3) as client:
        client.settimeout(8)
        client.sendall((json.dumps(request) + "\n").encode())
        return json.loads(client.recv(65536).decode()).get("result")


def require_idle() -> None:
    if kodi_rpc("Player.GetActivePlayers") != []:
        raise RuntimeError("active player or JSON-RPC error")


def audio_settings(required: tuple[str, ...] | None = None) -> dict:
    """Return supported audio settings; require an exact set when requested."""
    values = {}
    for key in required or AUDIO_SETTINGS:
        result = kodi_rpc("Settings.GetSettingValue", {"setting": key})
        if isinstance(result, dict) and "value" in result:
            values[key] = result["value"]
        elif required is not None:
            raise RuntimeError("required audio setting unavailable: " + key)
    return values


def restore_audio_settings(expected: dict) -> None:
    """Repair Kodi 22's bounded HDMI-startup fallback after the engine settles."""
    last = None
    keys = tuple(expected)
    for _ in range(15):
        for key, value in expected.items():
            kodi_rpc("Settings.SetSettingValue", {"setting": key, "value": value})
        time.sleep(2)
        last = audio_settings(keys)
        if last == expected:
            return
    raise RuntimeError("audio settings did not survive post-start verification: " + repr(last))


def atomic_profile_write(data: bytes) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=".astertv-r46-", dir=GUISETTINGS.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.chmod(temporary, 0o600);os.replace(temporary, GUISETTINGS)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)


def pin_release_audio_file() -> None:
    text = GUISETTINGS.read_text()
    for setting in ("audiooutput.audiodevice", "audiooutput.passthroughdevice"):
        pattern = r'(<setting id="' + re.escape(setting) + r'">)[^<]*(</setting>)'
        text, count = re.subn(pattern, r"\g<1>" + HDMI_ROUTE + r"\g<2>", text, count=1)
        if count != 1:raise RuntimeError("missing profile audio route: " + setting)
    atomic_profile_write(text.encode())


def unit_state(verb: str) -> str:
    return subprocess.run(["systemctl", verb, PULSE], text=True,
                          capture_output=True, check=False).stdout.strip()


def configure_exclusive_hdmi() -> None:
    subprocess.run(["systemctl", "stop", PULSE], check=True, timeout=30)
    subprocess.run(["systemctl", "disable", PULSE], check=True, timeout=30)
    subprocess.run(["systemctl", "mask", PULSE], check=True, timeout=30)
    if unit_state("is-active") == "active":raise RuntimeError("PulseAudio remained active")
    if unit_state("is-enabled") != "masked":raise RuntimeError("PulseAudio mask did not persist")
    pin_release_audio_file()


def restore_pulse_state(enabled: str, active: str) -> None:
    subprocess.run(["systemctl", "unmask", PULSE], check=False, timeout=30)
    if enabled == "masked":
        subprocess.run(["systemctl", "mask", PULSE], check=True, timeout=30)
    else:
        subprocess.run(["systemctl", "enable" if enabled == "enabled" else "disable", PULSE],
                       check=True, timeout=30)
        subprocess.run(["systemctl", "start" if active == "active" else "stop", PULSE],
                       check=True, timeout=30)


def set_24h_clock() -> None:
    result = kodi_rpc("Settings.SetSettingValue", {"setting": CLOCK_SETTING, "value": "24hours"})
    current = kodi_rpc("Settings.GetSettingValue", {"setting": CLOCK_SETTING})["value"]
    if result is not True or current != "24hours":
        raise RuntimeError("24-hour clock setting did not persist")


def addon_state(addon_id: str) -> bool | None:
    result = kodi_rpc("Addons.GetAddonDetails", {
        "addonid": addon_id, "properties": ["enabled"]})
    if not isinstance(result, dict) or not isinstance(result.get("addon"), dict):
        return None
    value = result["addon"].get("enabled")
    return value if isinstance(value, bool) else None


def set_addon_state(addon_id: str, enabled: bool) -> None:
    result = kodi_rpc("Addons.SetAddonEnabled", {
        "addonid": addon_id, "enabled": enabled})
    if result != "OK" or addon_state(addon_id) is not enabled:
        raise RuntimeError("add-on activation failed: " + addon_id)


def activate_runtime_addons() -> None:
    for addon_id in RUNTIME_ADDONS:
        set_addon_state(addon_id, True)
    for addon_id in LAB_ONLY_ADDONS:
        set_addon_state(addon_id, False)


def snapshot_rows() -> tuple[dict, list[dict]]:
    manifest = json.loads(SNAPSHOT_MANIFEST.read_text())
    if manifest.get("release") != RELEASE or manifest.get("credentials_included") is not False:
        raise RuntimeError("unexpected snapshot release or credential policy")
    rows = manifest.get("files")
    if not isinstance(rows, list) or not rows:
        raise RuntimeError("empty snapshot manifest")
    for row in rows:
        relative = Path(row["path"])
        if relative.is_absolute() or ".." in relative.parts or "addon_data" in relative.parts:
            raise RuntimeError("unsafe snapshot path")
        source = SNAPSHOT / relative
        if not source.is_file() or source.stat().st_size != row["bytes"] or sha(source) != row["sha256"]:
            raise RuntimeError("snapshot mismatch: " + row["path"])
    return manifest, rows


def verify_installed(rows: list[dict]) -> None:
    for row in rows:
        target = ADDONS / row["path"]
        if not target.is_file() or target.stat().st_size != row["bytes"] or sha(target) != row["sha256"]:
            raise RuntimeError("installed snapshot mismatch: " + row["path"])


def main() -> None:
    global CHECKPOINT
    node = os.uname().nodename
    if node not in TARGETS:
        raise RuntimeError("AsterTV Family/Bedroom host only")
    role, family_audio = TARGETS[node]
    CHECKPOINT = Path("/storage/.aster-checkpoints/astertv-v2.0.7-release-20261031-" + role)
    if CHECKPOINT.exists() or Path("/storage/.aster-recovery-required").exists():
        raise RuntimeError("checkpoint/recovery guard")
    require_idle()
    saved_audio = audio_settings()
    expected_audio = RELEASE_AUDIO if family_audio else saved_audio
    saved_pulse_enabled = unit_state("is-enabled")
    saved_pulse_active = unit_state("is-active")
    saved_clock = kodi_rpc("Settings.GetSettingValue", {"setting": CLOCK_SETTING})["value"]
    saved_addon_states = {
        addon_id: addon_state(addon_id)
        for addon_id in RUNTIME_ADDONS + LAB_ONLY_ADDONS
    }
    manifest, rows = snapshot_rows()
    if sha(SPLASH_SOURCE) != SPLASH_SHA:
        raise RuntimeError("unexpected splash hash")
    if not KEYMAP_SOURCE.is_file():
        raise RuntimeError("release keymap missing")
    addon_names = sorted(path.name for path in SNAPSHOT.iterdir() if path.is_dir())
    if not addon_names:
        raise RuntimeError("snapshot addon set empty")

    CHECKPOINT.mkdir(mode=0o700, parents=True)
    old_addons = CHECKPOINT / "addons"
    old_addons.mkdir(mode=0o700)
    staged: dict[str, Path] = {}
    for name in addon_names:
        candidate = ADDONS / ("." + name + ".v207-new")
        if candidate.exists():
            raise RuntimeError("stale candidate: " + str(candidate))
        shutil.copytree(SNAPSHOT / name, candidate, symlinks=False)
        staged[name] = candidate

    metadata = {
        "release": RELEASE,
        "snapshot_manifest_sha256": sha(SNAPSHOT_MANIFEST),
        "addons": addon_names,
        "keymap_before": sha(KEYMAP) if KEYMAP.is_file() else None,
        "splash_before": sha(SPLASH) if SPLASH.is_file() else None,
        "credentials_or_addon_data_touched": False,
        "audio_settings_touched": True,
        "target_role": role,
        "release_audio_settings": expected_audio,
        "pulseaudio_enabled_before": saved_pulse_enabled,
        "pulseaudio_active_before": saved_pulse_active,
        "audio_settings_before": saved_audio,
        "clock_setting_before": saved_clock,
        "addon_states_before": saved_addon_states,
    }
    (CHECKPOINT / "manifest.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
    if KEYMAP.is_file():
        shutil.copy2(KEYMAP, CHECKPOINT / "g20s-pro-plus.xml.before")
    if SPLASH.is_file():
        shutil.copy2(SPLASH, CHECKPOINT / "Splash.png.before")
    shutil.copy2(GUISETTINGS, CHECKPOINT / "guisettings.xml.before")

    moved_old: list[str] = []
    installed: list[str] = []
    subprocess.run(["systemctl", "stop", "kodi"], check=True, timeout=45)
    try:
        if family_audio:
            configure_exclusive_hdmi()
        for name in addon_names:
            target = ADDONS / name
            if target.exists():
                os.replace(target, old_addons / name)
                moved_old.append(name)
            os.replace(staged[name], target)
            installed.append(name)
        KEYMAP.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        SPLASH.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        shutil.copy2(KEYMAP_SOURCE, KEYMAP)
        shutil.copy2(SPLASH_SOURCE, SPLASH)
        verify_installed(rows)
        if sha(SPLASH) != SPLASH_SHA:
            raise RuntimeError("installed splash mismatch")
        subprocess.run(["systemctl", "start", "kodi"], check=True, timeout=45)
        time.sleep(8)
        if subprocess.run(["systemctl", "is-active", "--quiet", "kodi"]).returncode != 0:
            raise RuntimeError("Kodi did not remain active")
        restore_audio_settings(expected_audio)
        set_24h_clock()
        activate_runtime_addons()
        require_idle()
    except Exception:
        subprocess.run(["systemctl", "stop", "kodi"], check=False, timeout=45)
        failed = CHECKPOINT / "failed-v207"
        failed.mkdir(mode=0o700, exist_ok=True)
        for name in reversed(installed):
            target = ADDONS / name
            if target.exists():
                os.replace(target, failed / name)
            original = old_addons / name
            if original.exists():
                os.replace(original, target)
        if (CHECKPOINT / "g20s-pro-plus.xml.before").is_file():
            shutil.copy2(CHECKPOINT / "g20s-pro-plus.xml.before", KEYMAP)
        elif KEYMAP.exists():
            KEYMAP.unlink()
        if (CHECKPOINT / "Splash.png.before").is_file():
            shutil.copy2(CHECKPOINT / "Splash.png.before", SPLASH)
        elif SPLASH.exists():
            SPLASH.unlink()
        shutil.copy2(CHECKPOINT / "guisettings.xml.before", GUISETTINGS)
        restore_pulse_state(saved_pulse_enabled, saved_pulse_active)
        subprocess.run(["systemctl", "start", "kodi"], check=True, timeout=45)
        time.sleep(8)
        try:
            restore_audio_settings(saved_audio)
            kodi_rpc("Settings.SetSettingValue", {"setting": CLOCK_SETTING, "value": saved_clock})
            for addon_id, enabled in saved_addon_states.items():
                if enabled is not None:
                    set_addon_state(addon_id, enabled)
        except Exception:
            Path("/storage/.aster-recovery-required").write_text(
                "AsterTV v2.0.7 rollback restored add-ons but not the pre-deployment audio route.\n")
        raise
    print(json.dumps({"installed": True, "release": RELEASE, "host": node,
                      "target_role": role, "checkpoint": str(CHECKPOINT), "addons": len(addon_names),
                      "snapshot_files": len(rows), "splash_sha256": SPLASH_SHA}, sort_keys=True))


if __name__ == "__main__":
    main()
